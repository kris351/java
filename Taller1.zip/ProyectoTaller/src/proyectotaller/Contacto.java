package proyectotaller;

public class Contacto {
    private String nombre;
    private Telefono telefono;
    private CorreoElectronico correoElectronico;

    // Constructor sin parámetros
    public Contacto() {
        this.nombre = "";
        this.telefono = new Telefono();
        this.correoElectronico = new CorreoElectronico();
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Telefono getTelefono() {
        return telefono;
    }

    public void setTelefono(Telefono telefono) {
        this.telefono = telefono;
    }

    public CorreoElectronico getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(CorreoElectronico correoElectronico) {
        this.correoElectronico = correoElectronico;
    }
 
    // Método para verificar el teléfono
    // nombre: verificarTelefono(numero)
    // descripcion: verifica que el numero cumpla con lo que se describe mas abajo y
    // retorna verdadero si se cumplen las condiones, y falso en caso contrario.
    // D.E: numero      // D.S: ------------------
    public boolean verificarNombre(String nombre){
        boolean ban = false;
        if (!nombre.isEmpty()) {
            ban = true;
        } else {
            System.out.println("El nombre no puede estar vacío.");
        }
        return ban;
    }
    
    // Método para mostrar la información del contacto
    // nombre: mostrarcontacto()
    // descripcion: muestra todos los datos del contacto.
    // D.E: ---------------      // D.S: ------------------
    public void mostrarContacto() {
        System.out.println(toString());
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " \tTelefono: +" + telefono + "\tCorreo Electronico: " + correoElectronico;
    }
    
    
}