package proyectotaller;

public class Telefono {
    private String numero;

    // Constructor sin parámetros
    public Telefono() {
        this.numero = "";
    }

    // Getter y Setter
    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
            this.numero = numero;
    }

    // Método para verificar el teléfono
    // nombre: verificarTelefono(numero)
    // descripcion: verifica que el numero cumpla con lo que se describe mas abajo y
    // retorna verdadero si se cumplen las condiones, y falso en caso contrario.
    // D.E: numero      // D.S: ------------------
   public boolean verificarTelefono(String numero) {
        boolean ban = false;                                   //numero.matches sirve para verificar que de 1-4 sea el cod.pais,
        // el numero tiene que tener 11 o mas digitos     //2-5 el cod.area y de 4-9 el resto del numero de telefono
        if((numero.length() >= 11) && (numero.matches("\\d{1,4} \\d{2,5} \\d{4,9}"))){
            ban = true;
        } else {
            System.out.println("Número de teléfono inválido");
        }
        return ban;
        
    }
   
    @Override
    public String toString() {
        return numero;
    }
}