package proyectotaller;

public class CorreoElectronico {
    private String correo;

    // Constructor sin parámetros
    public CorreoElectronico() {
        this.correo = "";
    }

    // Getter y Setter
    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;       
    }

    // Método para verificar el correo electrónico
    // Método para verificar el teléfono
    // nombre: verificarTelefono(numero)
    // descripcion: verifica que el numero cumpla con lo que se describe mas abajo y
    // retorna verdadero si se cumplen las condiones, y falso en caso contrario.
    // D.E: numero      // D.S: ------------------
    public boolean verificarCorreo(String correo) {
        boolean ban =  false;
        if (correo.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")){
            ban = true;
        } else {
            System.out.println("Correo Invalido");
        }
        return ban;
    }

    @Override
    public String toString() {
        return correo;
    }
}
