package proyectotaller;

public class Contacto {
    private String nombre;
    private Telefono telefono;
    private CorreoElectronico correoElectronico;

    // Constructor sin parámetros
    public Contacto() {
        this.nombre = "";
        this.telefono = new Telefono();
        this.correoElectronico = new CorreoElectronico();
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (!nombre.isEmpty()) {
            this.nombre = nombre;
        } else {
            System.out.println("El nombre no puede estar vacío.");
        }
    }

    public Telefono getTelefono() {
        return telefono;
    }

    public void setTelefono(Telefono telefono) {
        this.telefono = telefono;
    }

    public CorreoElectronico getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(CorreoElectronico correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    // Método para mostrar la información del contacto
    public void mostrarContacto() {
        System.out.println(toString());
    }

    @Override
    public String toString() {
        return "Nombre:" + this.nombre + " Numero de Telefono:" + telefono + " CorreoElectronico:" + correoElectronico +"\n";
    }
    
    
}