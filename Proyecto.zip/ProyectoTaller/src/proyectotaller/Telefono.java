package proyectotaller;

public class Telefono {
    private String numero;

    // Constructor sin parámetros
    public Telefono() {
        this.numero = "";
    }

    // Getter y Setter
    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
            this.numero = numero;
    }

    // Método para verificar el teléfono
   public boolean verificarTelefono(String numero) {
        boolean ban = false;
        if((numero.length() >= 11 && numero.length() <= 16) && (numero.matches("\\+\\d{1,4}\\d{2,5}\\d{4,9}"))){
            ban = true;
        } else {
            System.out.println("Número de teléfono inválido");
        }
        return ban;
        
    }
   
    @Override
    public String toString() {
        return numero;
    }
}