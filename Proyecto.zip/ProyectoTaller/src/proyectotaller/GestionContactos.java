
package proyectotaller;

import java.util.Scanner;

public class GestionContactos {
    private static Contacto[] contactos = new Contacto[5]; // Arreglo de contactos
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        int indiceContacto = 0;

        while (true) {
            mostrarMenu();
            opcion = sc.nextInt();
            sc.nextLine(); // Limpiar el buffer
            
            switch (opcion) {
                case 1:
                    if (indiceContacto < 5) {
                        agregarContacto(indiceContacto);
                        indiceContacto++;
                    } else {
                        System.out.println("Ya se han ingresado los 5 contactos.");
                    }
                    break;
                case 2:
                    mostrarContactos();
                    break;
                case 3:
                    modificarTelefono();
                    break;
                case 0:
                    System.out.println("---- FIN DEL PROGRAMA ---");
                    return;
                default:
                    System.out.println("OPCION INVALIDA");
            }
        }
    }

    private static void mostrarMenu() {
        System.out.println("GESTION DE CONTACTOS");
        System.out.println("1. AGREGAR NUEVO CONTACTO");
        System.out.println("2. MOSTRAR CONTACTOS YA AGENDADOS");
        System.out.println("3. MODIFICAR EL TELEFONO DE UN CONTACTO");
        System.out.println("0. SALIR");
        System.out.print("INGRESE UNA OPCION: ");
    }

    private static void agregarContacto(int indice) {
        Contacto contacto = new Contacto();
        String nombre;
        String telefono;
        String correo;

        System.out.print("Ingrese el nombre: ");
        nombre = sc.nextLine();
        contacto.setNombre(nombre);

        // Validar y pedir teléfono
        Telefono telefonoObj = new Telefono();
        boolean telefonoValido = false;
        
        do {
            System.out.print("Ingrese el teléfono: ");
            telefono = sc.nextLine();
            telefonoValido = telefonoObj.verificarTelefono(telefono);
            telefonoObj.setNumero(telefono);
        } while (!telefonoValido);
        
        telefonoObj.setNumero(telefono);
        contacto.setTelefono(telefonoObj);

        // Validar y pedir correo electrónico
        CorreoElectronico correoObj = new CorreoElectronico();
        boolean correoValido = false;

        do {
            System.out.print("Ingrese el correo electrónico: ");
            correo = sc.nextLine();
            correoValido = correoObj.verificarCorreo(correo);
            correoObj.setCorreo(correo); 
        } while (!correoValido);

        contacto.setCorreoElectronico(correoObj);

        contactos[indice] = contacto;
        System.out.println("Contacto agregado correctamente.");
    }

    private static void mostrarContactos() {
        if (contactos[0] == null) {
            System.out.println("No se han agregado contactos.");
        } else {
            System.out.println("Lista de contactos:");
            for (int i = 0; i < 5; i++) {
                if (contactos[i] != null) {
                    contactos[i].mostrarContacto();
                    System.out.println("-------------------");
                }
            }
        }
    }

    private static void modificarTelefono() {
        System.out.print("Ingrese el índice del contacto a modificar (0-4): ");
        int indice = sc.nextInt();
        sc.nextLine(); // Limpiar buffer

        if (indice >= 0 && indice < 5 && contactos[indice] != null) {
            System.out.print("Ingrese el nuevo teléfono: ");
            String nuevoTelefono = sc.nextLine();
            Telefono nuevoTelefonoObj = new Telefono();
            nuevoTelefonoObj.setNumero(nuevoTelefono);
            contactos[indice].setTelefono(nuevoTelefonoObj);
            System.out.println("Teléfono modificado correctamente.");
        } else {
            System.out.println("Índice de contacto no válido.");
        }
    }
}

